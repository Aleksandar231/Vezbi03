/**
 * 
 */
/**
 * @author ilija
 *
 */
module labvezbi3 {
}