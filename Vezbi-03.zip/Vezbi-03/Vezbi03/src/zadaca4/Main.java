package zadaca4;

public class Main {

	public static void main(String[] args) {
		Paricka par1 = new Paricka();
		par1.brNaFrlanja();
		par1.pecatiBrojNaFrlanja();
		par1.pecatiGlava();
		par1.pecatiPismo();
		par1.reset();
		par1.brNaFrlanja();
	    par1.pecatiGlava();
	    par1.pecatiPismo();

	}

}
