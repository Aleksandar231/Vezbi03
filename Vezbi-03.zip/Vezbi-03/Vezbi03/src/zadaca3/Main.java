package zadaca3;

public class Main {

	public static void main(String[] args) {
		PC pc1 = new PC();
		pc1.prvMetod(10, 500);

	}

}
